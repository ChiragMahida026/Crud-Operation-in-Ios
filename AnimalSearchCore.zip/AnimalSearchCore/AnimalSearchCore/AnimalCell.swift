//
//  AnimalCell.swift
//  AnimalSearchCore
//
//  Created by bmiit on 12/04/22.
//

import UIKit

class AnimalCell:UITableViewCell{
    
    
    @IBOutlet weak var AnimalLabel: UILabel!
    @IBOutlet weak var DescriptionLabel: UILabel!
    
    
}
